// 接收来自后台的消息
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    console.log('收到来自 ' + (sender.tab ? "content-script(" + sender.tab.url + ")" : "popup或者background") + ' 的消息：', request);
    if (request.cmd == 'analysisGitLab') {
        sendResponse(analysisGitLab())
    } else {
        sendResponse('我收到你的消息了：' + JSON.stringify(request));
    }
});

document.addEventListener('DOMContentLoaded', function () {
    console.log("DOMContentLoaded");

});
window.onload = function () {
    console.log("window onload");
    setInterval(() => {
        pageChange()
    }, 1000);

    pageChange()
    if (window.location.href.indexOf('civstest.html') > 0) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(n => {
            document.addEventListener(n, function (e) {
                e.preventDefault();
                e.stopPropagation();
            }, false)
        })
        document.addEventListener('drop', function (e) {
            e.preventDefault();
            var files = e.dataTransfer.files
            if (files != null && files.length > 0) {
                console.log(files.length + "个文件");
                var file = files[0]
                readFile(file)
            } else {
                console.log("没有文件");
            }
            // var items = e.dataTransfer.items
            // if (items != null && items.length > 0) {
            //     console.log(items.length + "个item");
            // } else {
            //     console.log("没有items");
            // }
            // var types = e.dataTransfer.types
            // if (types != null && types.length > 0) {
            //     console.log(types.length + "个type");
            // } else {
            //     console.log("没有types");
            // }
        })
        function readFile(file) {
            var reader = new FileReader();
            reader.onload = function (e) {
                if (e.target.result.indexOf('data:image') == 0) {
                    document.getElementById('photoBase64').innerHTML = e.target.result.split(',')[1]
                }

            }
            reader.readAsDataURL(file);
        }
    }
}
function pageChange() {
    try {
        if (window.location.href == 'http://20.198.37.107:18083/signin' || window.location.href == 'http://20.198.37.127:18083/signin') {
            console.log('当前是Apollo登录页面');
            document.getElementsByTagName('input')[0].value = PsbcConstans.apollo_username;
            document.getElementsByTagName('input')[1].value = PsbcConstans.apollo_pwd;
        } else if (window.location.href.endsWith(':18083/config.html?#/appid=mbdp-proxy-public')) {
            let btns = document.getElementsByClassName('col-md-6 col-sm-6 text-right')[1]
            if (document.getElementById('btn-open-face')) return;
            var btnclose = document.createElement('button')
            btnclose.id = 'btn-open-face'
            btnclose.className = 'btn btn-danger btn-sm'
            btnclose.innerHTML = '全关'
            btnclose.addEventListener('click', function () {
                closeFace('0')
            })
            btns.prepend(btnclose)
            var btnopen = document.createElement('button')
            btnopen.id = 'btn-open-face'
            btnopen.className = 'btn btn-success btn-sm'
            btnopen.innerHTML = '全开'
            btnopen.addEventListener('click', function () {
                closeFace('1')
            })
            btns.prepend(btnopen)

        } else if (window.location.href.indexOf('merge_requests') > 0 && window.location.href.endsWith('diffs')) {
            try {
                if (document.getElementById('btn-export')) return;
                console.log('当前是代码diff页面');
                let target = document.getElementsByClassName('clearfix dropdown')[0]
                let div = this.document.createElement('div')
                div.id = 'btn-export'
                div.className = 'd-none d-md-block btn gl-button btn-default btn-grouped js-issuable-edit'
                div.style = 'background-color: #108548;margin-left:8px;color:white;'
                div.innerHTML = '导出代码走查单'
                div.onclick = function () {
                    window.location.replace("javascript:var content='';var childs=document.getElementsByClassName('col-12 col-md-auto diff-files-holder container-limited limit-container-width mx-lg-auto px-3')[0].children;for(var i=0;i<childs.length;i++){content+=childs[i].getElementsByClassName('dropdown-item')[0].href+'\\n'}")
                }
                target.appendChild(div)
            } catch (e) {

            }
        }
    } catch (e) {
        console.log('error', e);

    }
}



function myAlert(msg) {
    alert(msg)
}

function analysisGitLab() {
    var content = '';
    try {
        var childs = document.getElementsByClassName('col-12 col-md-auto diff-files-holder container-limited limit-container-width mx-lg-auto px-3')[0].children;
        for (var i = 0; i < childs.length; i++) {
            content += childs[i].getElementsByClassName('dropdown-item')[0].href + '\n'
        }
    } catch (e) {
        console.log(e)
    }
    if (content == '') {
        try {
            var panels = document.getElementsByClassName('diffs tab-pane')[0].getElementsByClassName('file-actions gl-display-none gl-sm-display-flex')
            for (var i = 0; i < panels.length; i++) {
                content += panels[i].lastElementChild.href + '\n'
            }
        } catch (e) {
            console.log(e)
            content = '解析错误,请在正确的页面使用'
        }
    }
    return content

}

function closeFace(state) {
    var content = '解析错误,请在正确的页面使用'
    if (!window.location.href.endsWith('mbdp-proxy-public')) {
        alert(content)
        return
    }
    try {
        var table = document.getElementsByClassName('table table-bordered table-striped table-hover')[0]
        console.log(table);
        var btns = table.getElementsByClassName('text-center ng-scope')
        console.log(btns);
        for (let index = 0; index < 4; index++) {
            const btn = btns[index].children[0];
            console.log(btn);
            btn.click()
            var editor = document.getElementById('valueEditor')
            editor.value = state
            let input_event = new InputEvent('input', {
                view: window,
                bubbles: true,
                cancelable: false,
                which: 0,
                composed: true,
                isTrusted: true,
                isComposing: true,
                data: state,
                inputType: 'insertText'
            })
            editor.dispatchEvent(input_event)
            var btn_commit = document.getElementById('itemModal').getElementsByClassName('btn btn-primary ng-binding')[0]
            btn_commit.click()
        }
        setTimeout(() => {
            let btnCommit = document.getElementsByClassName('col-md-6 col-sm-6 text-right header-buttons')[0].children[0]
            if (btnCommit.innerHTML.indexOf('发布') > -1) {
                btnCommit.click()
                var btnRelease = document.getElementById('releaseModal').getElementsByClassName('btn btn-primary ng-binding')[0]
                btnRelease.click()
            }
        }, 1500);
    } catch (e) {
        console.log(e)
        alert(content)
    }
    return content
}

function sleep(time) {
    let start = Date.now()
    let end = start + time
    while (true) {
        if (Date.now() > end) {
            return
        }
    }
}


