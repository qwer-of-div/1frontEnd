function newTabMsg(address) {
	chrome.tabs.create({ url: address })
}

function to_SIT_Apollo() {
	newTabMsg('http://20.198.37.107:18083/signin')
}

function to_T1_Apollo() {
	newTabMsg('http://20.198.37.127:18083/signin')
}
function to_Face_Collect() {
	newTabMsg('http://20.12.6.50:8100/civstest.html')
}

window.onload = function () {
	document.getElementById('btn_sit_apollo').onclick = this.to_SIT_Apollo
	document.getElementById('btn_t1_apollo').onclick = this.to_T1_Apollo
	document.getElementById('btn_face_collect').onclick = this.to_Face_Collect
}