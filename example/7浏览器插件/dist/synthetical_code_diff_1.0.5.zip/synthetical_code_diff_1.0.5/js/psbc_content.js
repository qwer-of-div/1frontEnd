document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('content').innerText = localStorage.getItem('psbc_msg')
})